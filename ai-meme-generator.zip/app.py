from flask import Flask, render_template, request
from diffusers import StableDiffusionPipeline
import torch, os, uuid

app = Flask(__name__)

pipe = StableDiffusionPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5",
    torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32
).to("cuda" if torch.cuda.is_available() else "cpu")

OUTPUT_FOLDER = "static/outputs"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

def generate_caption(topic):
    return f"When {topic} happens and you try to stay calm 😂🔥"

def generate_hashtags(topic):
    base = topic.replace(" ", "")
    return f"#{base} #gaming #meme #viral #funny"

@app.route("/", methods=["GET", "POST"])
def index():
    image_path = None
    caption = None
    hashtags = None

    if request.method == "POST":
        topic = request.form["topic"]

        prompt = f"{topic}, funny situation, expressive face, meme style, high detail"

        image = pipe(prompt).images[0]

        filename = f"{uuid.uuid4()}.png"
        file_path = os.path.join(OUTPUT_FOLDER, filename)
        image.save(file_path)

        image_path = "/" + file_path
        caption = generate_caption(topic)
        hashtags = generate_hashtags(topic)

    return render_template("index.html", image_path=image_path, caption=caption, hashtags=hashtags)

if __name__ == "__main__":
    app.run(debug=True)
